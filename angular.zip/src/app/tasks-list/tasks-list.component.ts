import { Component } from '@angular/core';
import { Task } from '../Models/Task';
import{state}from'../store/selectors/task.selector'
import{Store}from'@ngrx/store'
import {Observable} from 'rxjs';
import{TasksState}from'../store/states/tasks.state'
@Component({
  selector: 'app-tasks-list',
  templateUrl: './tasks-list.component.html',
  styleUrls: ['./tasks-list.component.css']
})
export class TasksListComponent {
 todos$:Observable<Task[]>
 constructor(private readonly store: Store<TasksState>){
   this.todos$=store.select('tasks');
   console.log(this.todos$)
 }
}
