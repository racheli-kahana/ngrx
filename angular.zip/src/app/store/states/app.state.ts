import { initialTaskState, TasksState } from '../states/tasks.state'

//export{RouterReducerState}from'@ngrx/router-store'
export{TasksState,initialTaskState}from'../states/tasks.state'

export interface AppState{
task:TasksState
}

export const initialAppState={
  task:initialTaskState
}

export function getInitialState():AppState{
return initialAppState
}



