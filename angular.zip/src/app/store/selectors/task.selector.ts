import { Task } from 'src/app/Models/Task'
import{TasksState}from'../states/tasks.state'


//export const taskState=(taskstate:AppState)=>taskstate.task;

//export const tasks=createSelector(taskState,(tasksarr:TasksSate)=>tasksarr.tasks)
export const state=(taskstate:TasksState):Task[]=>taskstate.tasks
